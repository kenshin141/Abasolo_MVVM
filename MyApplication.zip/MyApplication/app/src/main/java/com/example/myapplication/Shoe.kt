package com.example.myapplication

data class Shoe(
    val name: String,
    val brand: String,
    val price: Double,
    val imageUrl: String
)
