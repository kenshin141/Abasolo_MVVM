package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load

class ShoeAdapter(private val shoes: List<Shoe>) : RecyclerView.Adapter<ShoeAdapter.ShoeViewHolder>() {

    class ShoeViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val shoeImage: ImageView = view.findViewById(R.id.shoeImage)
        val shoeName: TextView = view.findViewById(R.id.shoeName)
        val shoeBrand: TextView = view.findViewById(R.id.shoeBrand)
        val shoePrice: TextView = view.findViewById(R.id.shoePrice)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShoeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_shoe, parent, false)
        return ShoeViewHolder(view)
    }

    override fun onBindViewHolder(holder: ShoeViewHolder, position: Int) {
        val shoe = shoes[position]
        holder.shoeName.text = shoe.name
        holder.shoeBrand.text = shoe.brand
        holder.shoePrice.text = "$${shoe.price}"
        
        // Use Coil to load the image from URL
        holder.shoeImage.load(shoe.imageUrl) {
            crossfade(true)
            placeholder(android.R.drawable.ic_menu_gallery)
            error(android.R.drawable.ic_menu_report_image)
        }
    }

    override fun getItemCount() = shoes.size
}
